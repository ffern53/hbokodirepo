# Widget Setup Guide - Connecting Your Addon to the Skin

This guide shows you how to make your existing video addon content appear directly in the HBO Max skin.

## What You Have

✅ Video addon installed (Seren, The Crew, Umbrella, etc.)
✅ Real-Debrid configured and working
✅ Content playing successfully through the addon

## What You Want

✅ Content displayed beautifully in HBO Max skin
✅ Click and play directly from home screen
✅ TMDB fanart, Trakt integration, trailers
✅ No need to navigate through addon menus

## Step 1: Find Your Addon's Plugin Paths

Your addon uses plugin:// URLs to access content. You need to find these paths.

### Method 1: Check Addon's Code

1. Go to: `~/.kodi/addons/` (or your Kodi addons folder)
2. Find your addon folder (e.g., `plugin.video.seren`)
3. Look in `resources/lib/` for menu definitions

### Method 2: Enable Kodi Debug Log

1. Settings > System > Logging > Enable Debug Logging
2. Navigate through your addon manually
3. Check `kodi.log` for plugin:// URLs
4. Copy those URLs

### Method 3: Common Addon Paths

**Seren:**
```
plugin://plugin.video.seren/?action=trendingMovies
plugin://plugin.video.seren/?action=trendingShows
plugin://plugin.video.seren/?action=popularMovies
plugin://plugin.video.seren/?action=popularShows
plugin://plugin.video.seren/?action=myMovies
plugin://plugin.video.seren/?action=myShows
plugin://plugin.video.seren/?action=searchMenu
```

**The Crew:**
```
plugin://plugin.video.thecrew/?action=movies&url=trending
plugin://plugin.video.thecrew/?action=movies&url=popular
plugin://plugin.video.thecrew/?action=tvshows&url=trending
plugin://plugin.video.thecrew/?action=tvshows&url=popular
plugin://plugin.video.thecrew/?action=search
```

**Umbrella:**
```
plugin://plugin.video.umbrella/?action=movies&url=trending
plugin://plugin.video.umbrella/?action=movies&url=popular
plugin://plugin.video.umbrella/?action=tvshows&url=trending
plugin://plugin.video.umbrella/?action=tvshows&url=popular
```

## Step 2: Configure Home_WithWidgets.xml

I've created `Home_WithWidgets.xml` with widget placeholders. Here's how to set it up:

### Replace Placeholder Text

Open `Home_WithWidgets.xml` and find all instances of:
```xml
plugin://plugin.video.YOURADDON/
```

Replace with your actual addon, for example:
```xml
plugin://plugin.video.seren/
```

### Update Content Paths

Find these sections and update the paths:

**Featured/Trending Content (Line ~85):**
```xml
<content target="video">plugin://plugin.video.seren/?action=trendingMovies</content>
```

**Popular Movies (Line ~180):**
```xml
<content target="video">plugin://plugin.video.seren/?action=popularMovies</content>
```

### Add More Widget Rows

To add additional content rows (TV shows, genres, etc.), copy this template:

```xml
<control type="panel" id="8003">
    <left>0</left>
    <top>840</top>  <!-- Adjust position -->
    <width>1800</width>
    <height>300</height>
    <onleft>8003</onleft>
    <onright>8003</onright>
    <onup>8002</onup>
    <ondown>8004</ondown>
    <orientation>horizontal</orientation>
    <scrolltime>200</scrolltime>

    <!-- Your content path here -->
    <content target="video">plugin://plugin.video.seren/?action=trendingShows</content>

    <!-- Copy itemlayout and focusedlayout from existing widget -->
</control>
```

## Step 3: Enable Fanart and Metadata

Your addon should already pull from TMDB if it's configured properly. To verify:

### Check Addon Settings

1. Open your video addon settings
2. Look for sections like:
   - **Artwork**: Enable all fanart sources
   - **TMDB**: Enter API key if required (most addons include one)
   - **Trakt**: Connect your Trakt account
   - **Metadata**: Enable extended info

### Common Settings:

**Seren Settings:**
- Accounts > Trakt > Authorize
- Providers > Real-Debrid > Authorize
- Scraping > Enable pre-emptive termination
- General > Metadata provider > TMDb

**The Crew Settings:**
- Accounts > Trakt
- Accounts > Debrid > Real-Debrid
- Playback > Choose default action

## Step 4: Add Trailer Support

Trailers come from YouTube. Your addon needs to support them:

### Enable in Addon

Most addons have a setting like:
- "Enable trailers" ✅
- "Trailer source" → YouTube
- "Trailer quality" → 1080p

### In the Skin

The trailer button is already configured:
```xml
<onclick>PlayMedia($INFO[Container(8000).ListItem.Trailer])</onclick>
```

This plays the trailer from ListItem properties provided by your addon.

## Step 5: Rename and Activate

Once configured:

1. **Backup original:**
   ```
   mv Home.xml Home_Original.xml
   ```

2. **Activate widget version:**
   ```
   mv Home_WithWidgets.xml Home.xml
   ```

3. **Reload skin:**
   - In Kodi: Ctrl+Alt+R (or restart Kodi)

## Advanced: Multiple Content Sources

Want different sections from different addons? Mix and match:

```xml
<!-- Trending from Seren -->
<content target="video">plugin://plugin.video.seren/?action=trendingMovies</content>

<!-- Popular from The Crew -->
<content target="video">plugin://plugin.video.thecrew/?action=movies&url=popular</content>

<!-- My Trakt Watchlist -->
<content target="video">plugin://plugin.video.seren/?action=myMovies</content>
```

## Troubleshooting

### Content Not Showing

**Problem:** Widget shows empty or loading forever

**Solutions:**
1. Check plugin:// path is correct
2. Open addon manually to verify path works
3. Check Kodi log for errors
4. Try different content path

### Artwork Missing

**Problem:** No posters/fanart displaying

**Solutions:**
1. Enable all artwork in addon settings
2. Check TMDB integration
3. Wait - first load can be slow as cache builds
4. Clear Kodi cache and reload

### Can't Play Content

**Problem:** Clicking item doesn't play

**Solutions:**
1. Verify Real-Debrid is authorized in addon
2. Check addon can play content normally
3. Look for errors in kodi.log
4. Try: `<onclick>RunPlugin($INFO[ListItem.FileNameAndPath])</onclick>`

### Info Button Not Working

**Problem:** Info dialog doesn't show

**Solutions:**
1. Use: `<onclick>Action(Info)</onclick>`
2. Or: `<onclick>RunScript(script.extendedinfo,info=extendedinfo,name=$INFO[ListItem.Title])</onclick>`
3. Install Extended Info addon for better dialogs

## Example: Complete Seren Integration

Here's a real example with Seren addon:

```xml
<!-- Home.xml configured for Seren -->

<!-- Featured Hero Section -->
<content target="video">plugin://plugin.video.seren/?action=trendingMovies</content>

<!-- Popular Movies Row -->
<content target="video">plugin://plugin.video.seren/?action=popularMovies</content>

<!-- Popular TV Shows Row -->
<content target="video">plugin://plugin.video.seren/?action=popularShows</content>

<!-- My Trakt Collection -->
<content target="video">plugin://plugin.video.seren/?action=myMovies</content>

<!-- Search -->
<onclick>ActivateWindow(videos,plugin://plugin.video.seren/?action=searchMenu,return)</onclick>
```

## Extended Info Integration

For better movie/TV info dialogs with cast, similar titles, etc.:

### Install Extended Info

```
Settings > Add-ons > Install from repository > Kodi Add-on repository
> Information providers > Extended Info Mod
```

### Update Info Button

Change the Info button onclick to:
```xml
<onclick>RunScript(script.extendedinfo,info=extendedinfo,name=$INFO[Container(8000).ListItem.Title],year=$INFO[Container(8000).ListItem.Year])</onclick>
```

Now clicking Info shows:
- Full cast and crew
- Similar movies/shows
- Reviews
- Trailers
- Ratings from multiple sources

## Navigation Tips

### Menu Structure

The new home screen has horizontal scrolling content rows:
- Top menu switches between sections
- Each section has multiple horizontal rows
- Focus moves between rows with up/down
- Scroll left/right within each row

### Adding Section Labels

Add labels above each widget row:

```xml
<control type="label">
    <left>0</left>
    <top>515</top>  <!-- Just above widget -->
    <width>1800</width>
    <height>30</height>
    <font>font_body</font>
    <textcolor>text_primary</textcolor>
    <label>Popular Movies</label>
</control>
```

## Result

After setup, your home screen will:
- ✅ Display trending/popular content from your addon
- ✅ Show beautiful posters with TMDB artwork
- ✅ Play content directly when clicked
- ✅ Show info/trailers
- ✅ Look like a professional streaming app
- ✅ All with HBO Max styling

No more navigating through addon menus - everything is right on the home screen!
