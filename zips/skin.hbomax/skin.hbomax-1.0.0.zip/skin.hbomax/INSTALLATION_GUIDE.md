# HBO Max Skin - Installation & Setup Guide

## Quick Start

This HBO Max skin for Kodi is now complete! Follow these steps to install and use it.

## What's Included

✅ **19 XML Layout Files**:
- Home.xml - Main home screen
- MyVideoNav.xml - Movies & TV Shows browser
- Views.xml - Multiple view types (Poster, List, Wide)
- VideoOSD.xml - Video player controls
- DialogVideoInfo.xml - Movie/TV show information
- Settings.xml - Settings interface
- DialogContextMenu.xml - Right-click context menu
- DialogSelect.xml - Selection dialogs
- DialogBusy.xml - Loading indicator
- DialogConfirm.xml - Yes/No dialogs
- DialogNotification.xml - Notification popups
- DialogButtonMenu.xml - Button menus
- SideMenu.xml - Side navigation panel
- MusicVisualisation.xml - Music player interface
- FileManager.xml - File browser
- Font.xml - Font definitions
- colors.xml - Color scheme
- Includes.xml - Reusable components

✅ **Documentation**:
- README.md - Complete documentation
- TEXTURE_GUIDE.md - Texture specifications
- BRANDING_README.md - Branding assets guide
- BRANDING_ASSETS_NEEDED.txt - Quick reference for needed files

✅ **Color Scheme**: HBO Max purple (#B536DA) with dark backgrounds

## Installation Steps

### Step 1: Complete the Skin Assets

Before installing, you need to add texture files. The skin references these textures but they need to be created:

#### Required Textures

Create these in `media/textures/common/`:
- `white.png` - 1x1 white pixel (used for color fills)
- `gradient.png` - 1920x1080 vertical gradient
- `button-focus.png` - 300x60 button background
- `button-nofocus.png` - 300x60 button background
- `border.png` - Border frame
- `spinner.png` - 200x200 loading spinner
- `watched-icon.png` - Watched indicator

Create these in `media/textures/osd/`:
- `play.png`, `pause.png`, `stop.png`
- `rewind.png`, `forward.png`, `subtitles.png`
- All 64x64 pixels

**Quick Placeholder Method for Testing:**
You can create simple colored rectangles using any image editor:
1. Create a 1x1 white pixel PNG for `white.png`
2. Create basic shapes in HBO purple (#B536DA) for buttons
3. Use simple icons for media controls

### Step 2: Add Branding Assets

Add these three files:
1. **icon.png** (512x512) in root directory
2. **fanart.jpg** (1920x1080) in root directory
3. **logo.png** (400x120) in media/ directory

See `BRANDING_ASSETS_NEEDED.txt` for details.

### Step 3: Install in Kodi

1. **Locate your Kodi addons directory:**
   - **Windows**: `%APPDATA%\Kodi\addons\`
   - **macOS**: `~/Library/Application Support/Kodi/addons/`
   - **Linux**: `~/.kodi/addons/`

2. **Copy the entire `skin.hbomax` folder** to the addons directory

3. **Restart Kodi** or go to Settings > Add-ons > My add-ons > Look and feel > Skin

4. **Select "HBO Max"** from the list

5. **Apply the skin** - Kodi will reload with the new interface

## Testing Without Assets (Quick Start)

If you want to test the skin immediately without creating all textures:

1. Create just the minimum files:
   - A 1x1 white.png in `media/textures/common/`
   - Copy it to all other required texture locations with different names

2. Add placeholder images for icon/fanart/logo (any purple-themed images)

3. Install and test - you'll see the layout and colors, even if textures aren't perfect

## Customization

### Change Colors

Edit `xml/colors.xml`:
```xml
<color name="hbo_purple">B536DA</color>  <!-- Change to your color -->
<color name="background_primary">0E0E2C</color>  <!-- Change background -->
```

### Modify Layout

Each XML file controls a different screen:
- Edit `Home.xml` to change the home screen
- Edit `MyVideoNav.xml` to modify the library view
- Edit `VideoOSD.xml` to customize playback controls

### Change Fonts

1. Place custom font files (.ttf) in the `fonts/` directory
2. Edit `xml/Font.xml` to reference your fonts:
```xml
<font>
    <name>font_body</name>
    <filename>YourFont.ttf</filename>
    <size>20</size>
</font>
```

## Troubleshooting

### Skin won't load
- Check Kodi log file for XML syntax errors
- Ensure all required XML files are present
- Verify addon.xml is properly formatted

### Missing textures showing errors
- Create placeholder white.png files in the texture directories
- Check file paths match exactly what's in XML files

### Colors look wrong
- Verify color codes in colors.xml are in hex format without #
- Example: Use `B536DA` not `#B536DA`

### Layout issues
- Ensure resolution is set to 1920x1080 in addon.xml
- Coordinates are based on 1080p layout

## Development & Testing

### Enable Debug Logging
1. Settings > System > Logging
2. Enable "Enable debug logging"
3. Check kodi.log for errors

### Quick Reload
- Press `Ctrl + Alt + R` to reload the skin without restarting Kodi
- Useful for testing XML changes

### Validate XML
Use an XML validator or IDE with XML support to check for syntax errors

## Features

✨ **Views**: Poster Wall, List, Wide/Landscape
✨ **Navigation**: Top menu bar + side menu drawer
✨ **Dialogs**: Info, context menu, confirmations, notifications
✨ **Media Support**: Video, music, pictures, file browser
✨ **Playback**: Full OSD with progress bar and controls
✨ **Settings**: Complete settings interface
✨ **Animations**: Smooth fades and transitions

## Support

- **Kodi Documentation**: https://kodi.wiki/view/Skin_development
- **Example Skins**: Look at Estuary or other built-in skins for reference
- **XML Syntax**: https://kodi.wiki/view/Skin_XML_files

## License

GPL-2.0-or-later

## Legal

This skin is inspired by HBO Max's design. For personal/educational use only.
HBO Max is a trademark of Warner Bros. Discovery.

---

**Enjoy your HBO Max inspired Kodi experience!** 🎬✨
