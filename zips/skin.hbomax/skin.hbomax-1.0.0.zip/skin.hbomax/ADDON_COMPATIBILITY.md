# Addon Compatibility Guide

## Current Status

The HBO Max skin works with:
- ✅ Kodi's native library (movies, TV shows, music)
- ✅ Local file playback
- ✅ Video player controls (OSD)
- ✅ System functions

## Video Addon Compatibility

### How Kodi Addons Work

Video addons (Netflix, YouTube, etc.) can work in two ways:

1. **Using Skin Windows** - Addon uses your skin's MyVideoNav.xml
2. **Custom Windows** - Addon creates its own interface (bypasses your skin)

### What You Have Now

Your skin provides the player controls (VideoOSD.xml), so when ANY addon plays a video, your HBO Max player interface will appear. ✅

### What Might Need Work

**Addon browsing interfaces** - Some addons may look inconsistent because they use their own layouts.

## Making Addons Look Better

### Option 1: They Already Work (Mostly)
Many addons use Kodi's standard windows, which means:
- Your MyVideoNav.xml will display their content
- Your dialogs will be used
- Everything looks consistent

### Option 2: Add Addon-Specific Files (Advanced)

For addons that create custom windows, you can add specific XML files:

**Example: YouTube Addon**
```
xml/script-youtube-main.xml
```

**Example: Netflix Addon**
```
xml/script-netflix-browse.xml
```

You'd need to research each addon's window names.

## Testing With Addons

### Step 1: Install and Test
1. Install your skin
2. Install a video addon (like YouTube)
3. Navigate through the addon
4. Note what looks good and what doesn't

### Step 2: Check What Windows Are Used
Enable Kodi debug logging:
- Settings > System > Logging > Enable debug logging
- Open the addon
- Check kodi.log to see which windows are called

### Step 3: Create Custom Windows (If Needed)
- Copy MyVideoNav.xml structure
- Rename to match addon window name
- Customize for addon's specific needs

## Video Playback

**✅ GOOD NEWS:** Video playback from ANY source will use your VideoOSD.xml!

Whether the video comes from:
- Local library
- Video addon
- File browser
- Streaming addon

Your HBO Max-styled player controls will appear. This is already built in.

## Example: YouTube Addon

When you install the YouTube addon:

**✅ Will use your skin:**
- Video playback controls (your VideoOSD.xml)
- Dialog boxes
- Context menus
- Notifications

**⚠️ Might not use your skin:**
- YouTube's video browsing interface (depends on addon)

## Popular Addons Compatibility

### Usually Compatible (Use Standard Windows)
- Jellyfin for Kodi
- Plex for Kodi
- Emby for Kodi
- Most library-based addons

### May Need Custom Windows
- YouTube
- Twitch
- Netflix (if unofficial addon)
- Custom streaming addons

## Quick Test Method

1. Install the skin
2. Install YouTube addon
3. Browse YouTube videos
   - If it looks good: ✅ Working
   - If it looks odd: Need custom window
4. Play a video
   - Should use your VideoOSD.xml ✅

## Adding Generic Addon Support

Create a generic addon browser window:

**xml/script-skinshortcuts.xml**
**xml/MyPrograms.xml**
**xml/AddonBrowser.xml**

These can provide consistent styling for addon navigation.

## Bottom Line

**For Video Playback**: ✅ Ready to go! Any video from any source will use your player interface.

**For Addon Browsing**: ⚠️ Depends on the addon. Most will work fine, some may need custom windows.

## Recommendation

1. **Install and test** with your favorite addons
2. **Playback will definitely work** with your skin
3. **If addon browsing looks wrong**, you can create custom windows for specific addons
4. **Start simple** - use it with Kodi's library first, then add addon windows as needed

## Future Enhancements

To make a "complete" skin for all addons, you could add:
- xml/MyPrograms.xml (programs/addons menu)
- xml/AddonBrowser.xml (addon browser)
- xml/script-*.xml files (for popular addons)

But the core functionality is already there!
