# Branding Assets Needed

Place the following files in this directory:

## logo.png
- HBO Max logo with transparent background
- Recommended size: 400x120 pixels
- Format: PNG with alpha channel
- Color: Official HBO Max logo (purple/white)

## In Root Directory:

### icon.png
- 512x512 pixels
- Addon icon for Kodi interface
- Should represent HBO Max branding

### fanart.jpg
- 1920x1080 pixels
- Background artwork for the addon
- Dark theme with purple accents matching HBO Max style

## Legal Note
Ensure you have proper rights/permissions to use HBO Max branding elements.
This skin is for personal/educational use.
