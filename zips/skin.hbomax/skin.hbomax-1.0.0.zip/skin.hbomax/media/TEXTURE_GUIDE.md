# HBO Max Skin - Texture Guide

This document describes all the textures needed for the skin. Create these as PNG files with transparency.

## Common Textures (media/textures/common/)

### white.png
- 1x1 pixel white image (FFFFFF)
- Used as base for color diffuse overlays

### gradient.png
- 1920x1080 vertical gradient
- Top: transparent
- Bottom: solid black
- Used for overlays on featured content

### button-focus.png
- 300x60 rounded rectangle
- Fill: solid white or HBO purple
- Border radius: 8px

### button-nofocus.png
- 300x60 rounded rectangle
- Fill: semi-transparent or dark background
- Border radius: 8px

### border.png
- Simple 8px border frame
- Center transparent
- Used for poster/thumbnail borders

### spinner.png
- Circular loading spinner icon
- 200x200
- HBO purple color

## Dialog Textures (media/textures/dialogs/)

### dialog-bg.png
- Semi-transparent dark background
- Size: flexible (will be stretched)
- Color: dark with 90% opacity

### dialog-header.png
- Gradient header bar
- HBO purple to transparent

## OSD Textures (media/textures/osd/)

### progressbar-bg.png
- 1000x8 rectangle
- Dark gray background

### progressbar-fill.png
- 1000x8 rectangle
- HBO purple fill

### play-button.png
### pause-button.png
### stop-button.png
### rewind-button.png
### forward-button.png
- Standard media control icons
- 64x64 pixels
- White color
- Simple, modern design

## Branding

### logo.png (media/)
- HBO Max logo
- Transparent background
- Recommended size: 400x120 pixels

### icon.png (root)
- Addon icon for Kodi
- 512x512 pixels
- HBO Max logo or purple circular icon

### fanart.jpg (root)
- 1920x1080 background image
- HBO Max themed artwork
- Dark with purple accents

## Creating Textures

You can create these textures using:
- Adobe Photoshop/Illustrator
- GIMP (free)
- Inkscape (free, for vectors)
- Online tools like Figma

For placeholder testing, you can use simple colored rectangles.
