# Making HBO Max Skin into a Full Streaming App

## What You Want

A skin that works like the actual HBO Max app:
- Home page shows trending movies/shows
- Browse content by category (Action, Comedy, etc.)
- Click a movie → Get info → Play directly
- No separate addons needed
- Skin IS the app

## Current Status

Right now, the skin is a **visual wrapper**. It provides:
- ✅ Beautiful interface
- ✅ Navigation structure
- ✅ Player controls
- ❌ No content source (needs to be connected)

## What's Needed: Content Integration

To make this work like a real streaming app, you need to:

### Option 1: Use Kodi Library + Widgets (Easiest)

**How it works:**
- Use addon to populate Kodi's library (Seren, The Crew, etc.)
- Use skin widgets to display content on home screen
- Skin pulls from library and displays it

**Pros:**
- No coding required
- Uses existing addons
- Fully integrated experience

**Cons:**
- Requires separate addons for content
- Not truly "built-in" to skin

### Option 2: Build Custom Addon for Skin (Medium)

**How it works:**
- Create a companion addon (script.hbomax.content)
- Addon fetches data from streaming APIs (TMDB, Trakt, etc.)
- Skin displays the data

**Pros:**
- Appears built-in to skin
- Control over everything
- Professional approach

**Cons:**
- Requires Python coding
- Need API keys
- More complex

### Option 3: Integrate API Calls Directly (Advanced)

**How it works:**
- Use Kodi's JSON-RPC
- Fetch data from APIs within skin code
- Display dynamically

**Pros:**
- Fully integrated
- No separate addon

**Cons:**
- Very complex
- Limited by Kodi skin engine capabilities
- Not recommended approach

## Recommended Approach: Skin + Companion Addon

This is how professional skins like Aura and Arctic Zephyr work.

### Step 1: Create Content Addon

Create `script.hbomax.content` addon that:
- Fetches trending movies from TMDB API
- Gets popular TV shows
- Provides categories/genres
- Returns data to skin

### Step 2: Modify Skin to Use Addon

Update Home.xml to:
- Call the addon for content
- Display results in widgets
- Make items clickable to play

### Step 3: Add Smart Playlists

Create playlists for:
- Trending Movies
- Popular TV Shows
- By Genre
- Recently Added

## Detailed Implementation Plan

### Architecture

```
HBO Max Skin
    ↓
Companion Addon (script.hbomax.content)
    ↓
Content APIs (TMDB, Trakt, Real-Debrid, etc.)
    ↓
Playback via Resolvers
```

### Content Addon Structure

```python
script.hbomax.content/
├── addon.xml
├── default.py
├── resources/
│   ├── lib/
│   │   ├── api.py          # API calls
│   │   ├── content.py      # Content handling
│   │   └── player.py       # Playback handling
│   └── settings.xml        # API keys, etc.
```

### What the Addon Would Do

1. **Fetch Content**
```python
def get_trending_movies():
    # Call TMDB API
    # Return list of movies with:
    # - Title, poster, plot, year, rating
    # - Playable link (via Real-Debrid, etc.)
```

2. **Provide to Skin**
```python
# Skin calls: RunScript(script.hbomax.content, action=trending)
# Addon populates window properties
# Skin displays the data
```

3. **Handle Playback**
```python
def play_movie(movie_id):
    # Get streaming links
    # Resolve via debrid service
    # Pass to Kodi player
```

### Modified Home.xml (Example)

```xml
<!-- Trending Movies Section -->
<control type="list" id="9100">
    <left>60</left>
    <top>320</top>
    <width>1800</width>
    <height>450</height>

    <!-- Trigger addon to populate -->
    <onload>RunScript(script.hbomax.content,action=trending,target=9100)</onload>

    <itemlayout width="300" height="450">
        <!-- Poster from addon data -->
        <control type="image">
            <texture>$INFO[ListItem.Art(poster)]</texture>
        </control>
        <control type="label">
            <label>$INFO[ListItem.Label]</label>
        </control>
    </itemlayout>

    <focusedlayout width="300" height="450">
        <!-- Focused state -->
        <control type="image">
            <texture>$INFO[ListItem.Art(poster)]</texture>
            <bordertexture colordiffuse="hbo_purple">common/border.png</bordertexture>
        </control>
    </focusedlayout>

    <!-- Click to play -->
    <onclick>RunScript(script.hbomax.content,action=play,id=$INFO[ListItem.Property(id)])</onclick>
</control>
```

## Content Sources

To get actual content, you need:

### Free APIs (for metadata)
- **TMDB** (themoviedb.org) - Movie/TV info, posters ✅ Free
- **Trakt** - Trending, popular lists ✅ Free
- **Fanart.tv** - High quality artwork ✅ Free

### Streaming Sources (for playback)
- **Real-Debrid** - Premium link resolver 💰 Paid
- **AllDebrid** - Alternative debrid service 💰 Paid
- **Premiumize** - Another option 💰 Paid
- **Torrent Scrapers** - Free but complex ⚠️ Legal gray area

### Legal Considerations

⚠️ **Important:**
- TMDB/Trakt only provide metadata (info), not streams
- You need separate service for actual video playback
- Consider legal implications in your jurisdiction

## Existing Solutions You Can Integrate

Instead of building from scratch, integrate with:

### 1. Seren Addon
- Popular streaming addon
- Can populate Kodi library
- Use with your skin's library views

### 2. The Crew / The Oath
- Content aggregators
- Work with Trakt lists
- Can be called from skin widgets

### 3. Composite Addon
- Designed for skin integration
- Provides widgets
- Easy to implement

## Quick Implementation: Using Skin Widgets

**Easiest way to get what you want:**

### Step 1: Install Dependencies
```
- Install Seren or similar content addon
- Install script.skin.helper.service
- Install script.skinshortcuts
```

### Step 2: Modify Home.xml

Add widget containers:
```xml
<control type="panel" id="trending">
    <content target="video">
        plugin://plugin.video.seren/?action=trendingMovies
    </content>
</control>
```

### Step 3: Add Categories

```xml
<!-- Categories List -->
<control type="list" id="categories">
    <content>
        <item>
            <label>Trending</label>
            <onclick>Container.Update(plugin://plugin.video.seren/?action=trendingMovies)</onclick>
        </item>
        <item>
            <label>Popular</label>
            <onclick>Container.Update(plugin://plugin.video.seren/?action=popularMovies)</onclick>
        </item>
    </content>
</control>
```

## Complete Example: Integrated Home Screen

Here's what the modified Home.xml would look like with content:

```xml
<!-- Home Screen with Trending Content -->
<window id="home">
    <!-- Navigation stays same -->

    <!-- Trending Movies Widget -->
    <control type="panel" id="trending_movies">
        <left>60</left>
        <top>320</top>
        <content>plugin://plugin.video.seren/?action=trendingMovies</content>
        <onclick>RunPlugin($INFO[ListItem.FileNameAndPath])</onclick>
    </control>

    <!-- Popular TV Shows Widget -->
    <control type="panel" id="popular_tv">
        <left>60</left>
        <top>770</top>
        <content>plugin://plugin.video.seren/?action=trendingShows</content>
        <onclick>RunPlugin($INFO[ListItem.FileNameAndPath])</onclick>
    </control>
</window>
```

## Next Steps to Make This Real

### Phase 1: Use Existing Addons (Quickest)
1. Install Seren or The Crew addon
2. Modify Home.xml to add content widgets
3. Point widgets to addon content
4. Test and refine

**Time: 2-3 hours**

### Phase 2: Create Companion Addon (Clean Solution)
1. Create script.hbomax.content addon
2. Add TMDB API integration
3. Add Real-Debrid integration
4. Modify skin to use companion addon
5. Test thoroughly

**Time: 1-2 weeks** (requires Python coding)

### Phase 3: Polish (Final Touches)
1. Add caching for performance
2. Implement search functionality
3. Add user preferences
4. Create custom categories

**Time: Additional 1-2 weeks**

## Summary

**What you want IS possible**, but requires:

1. **Content Source** - Addon or API to get movie/show data
2. **Stream Resolver** - Service to get playable links (Real-Debrid, etc.)
3. **Widget Integration** - Connect skin to content source
4. **Modified Home.xml** - Display content widgets instead of static layout

**Easiest path:**
- Keep current skin structure
- Install Seren addon for content
- Modify Home.xml to add widgets from Seren
- Skin becomes full streaming interface

**Would you like me to:**
1. Modify the Home.xml to include content widgets (using existing addon)?
2. Create a companion addon template?
3. Show you specific widget implementations?
