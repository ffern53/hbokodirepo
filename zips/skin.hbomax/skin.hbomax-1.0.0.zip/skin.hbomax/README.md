# HBO Max Skin for Kodi

A modern, beautiful skin for Kodi inspired by HBO Max's signature purple color scheme and sleek interface design.

## Features

- **HBO Max Inspired Design**: Signature purple (`#B536DA`) color scheme with dark backgrounds
- **Multiple View Types**: Poster wall, list view, and wide/landscape views
- **Comprehensive Interface**:
  - Home screen with featured content
  - Movies and TV Shows libraries
  - Video player OSD with playback controls
  - Video information dialogs
  - Settings interface
  - Context menus
  - Side navigation menu
  - Music visualization
- **Modern UI Elements**: Smooth animations, gradients, and focus indicators
- **Responsive Navigation**: Intuitive menu system with breadcrumbs

## Installation

1. Copy the `skin.hbomax` folder to your Kodi addons directory:
   - **Windows**: `%APPDATA%\Kodi\addons\`
   - **Mac**: `~/Library/Application Support/Kodi/addons/`
   - **Linux**: `~/.kodi/addons/`

2. Add required texture files (see "Required Assets" section below)

3. In Kodi, go to Settings > Interface > Skin
4. Select "HBO Max" from the available skins

## Required Assets

### Textures (media/textures/common/)

You need to create the following texture files:

- **white.png**: 1x1 pixel white image
- **gradient.png**: 1920x1080 vertical gradient (transparent to black)
- **button-focus.png**: 300x60 rounded rectangle button
- **button-nofocus.png**: 300x60 rounded rectangle button (unfocused state)
- **border.png**: Border frame texture
- **spinner.png**: 200x200 loading spinner icon
- **watched-icon.png**: Watched indicator icon

### OSD Textures (media/textures/osd/)

- **play.png**: Play button icon (64x64)
- **pause.png**: Pause button icon (64x64)
- **stop.png**: Stop button icon (64x64)
- **rewind.png**: Rewind button icon (64x64)
- **forward.png**: Forward button icon (64x64)
- **subtitles.png**: Subtitles button icon (64x64)

### Branding Assets

- **media/logo.png**: HBO Max logo (400x120 recommended)
- **icon.png** (root): 512x512 addon icon
- **fanart.jpg** (root): 1920x1080 background artwork

See `media/TEXTURE_GUIDE.md` for detailed texture specifications.

## Color Scheme

The skin uses HBO Max's official color palette:

- **Primary Purple**: `#B536DA`
- **Dark Purple**: `#5B1A6B`
- **Blue Accent**: `#001EFF`
- **Background**: `#0E0E2C`
- **Secondary Background**: `#1A1A3E`
- **Text Primary**: `#FFFFFF`
- **Text Secondary**: `#B8B8CC`

## File Structure

```
skin.hbomax/
├── addon.xml                 # Skin metadata
├── icon.png                  # Addon icon (512x512)
├── fanart.jpg               # Background artwork (1920x1080)
├── fonts/                   # Font files
├── media/                   # Textures and images
│   ├── textures/
│   │   ├── common/         # Common UI textures
│   │   ├── dialogs/        # Dialog textures
│   │   ├── osd/            # Player control icons
│   │   └── buttons/        # Button textures
│   ├── logo.png            # HBO Max logo
│   ├── TEXTURE_GUIDE.md    # Texture specifications
│   └── BRANDING_README.md  # Branding asset guide
├── themes/                  # Theme variants
│   └── defaults/
└── xml/                     # UI layout files
    ├── Home.xml            # Home screen
    ├── MyVideoNav.xml      # Movies/TV Shows browser
    ├── Views.xml           # View type definitions
    ├── VideoOSD.xml        # Video player controls
    ├── DialogVideoInfo.xml # Video information dialog
    ├── Settings.xml        # Settings interface
    ├── DialogContextMenu.xml # Context menu
    ├── DialogSelect.xml    # Selection dialog
    ├── DialogBusy.xml      # Loading dialog
    ├── DialogButtonMenu.xml # Button menu
    ├── SideMenu.xml        # Side navigation
    ├── MusicVisualisation.xml # Music player
    ├── Font.xml            # Font definitions
    ├── colors.xml          # Color definitions
    └── Includes.xml        # Reusable components
```

## Customization

### Changing Colors

Edit `xml/colors.xml` to customize the color scheme:

```xml
<color name="hbo_purple">B536DA</color>
<color name="background_primary">0E0E2C</color>
```

### Modifying Fonts

Edit `xml/Font.xml` to change font sizes and styles. Place custom font files in the `fonts/` directory.

### Adding Custom Views

Add new view definitions to `xml/Views.xml` and reference them in window files.

## Development

### Prerequisites

- Kodi 19 (Matrix) or later
- Basic knowledge of XML
- Image editing software (for creating textures)

### Testing

1. Enable debugging in Kodi: Settings > System > Logging > Enable debug logging
2. Monitor the Kodi log file for skin-related errors
3. Use Kodi's "Reload skin" feature (Ctrl+Alt+R) for quick testing

## Support

For issues, questions, or contributions:

- Check the Kodi skin development documentation: https://kodi.wiki/view/Skin_development
- Review Kodi's built-in skin examples for reference

## Legal Notice

This skin is inspired by HBO Max's visual design. Ensure you have proper rights/permissions to use any HBO Max branding elements. This skin is for personal/educational use only.

## License

GPL-2.0-or-later

## Credits

Created for Kodi media center
Inspired by HBO Max interface design
