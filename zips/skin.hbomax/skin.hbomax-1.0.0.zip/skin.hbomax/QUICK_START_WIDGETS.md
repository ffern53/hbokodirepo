# Quick Start: Making Your Addon Work With The Skin

## What You Need

1. ✅ Your video addon installed and working (Seren, The Crew, Umbrella, etc.)
2. ✅ Real-Debrid configured in the addon
3. ✅ Can play content through the addon normally

## 5-Minute Setup

### Step 1: Find Your Addon ID

In Kodi:
- Settings > Add-ons > My add-ons > Video add-ons
- Click your addon
- Look at the addon ID (e.g., `plugin.video.seren`)

### Step 2: Edit Home_WithWidgets.xml

Open `xml/Home_WithWidgets.xml` and do a find/replace:

**Find:** `plugin.video.YOURADDON`
**Replace:** `plugin.video.seren` (or your actual addon ID)

Save the file.

### Step 3: Update Content Paths

Find these lines and update with your addon's paths:

**Line ~85 (Featured Content):**
```xml
<content target="video">plugin://plugin.video.seren/?action=trendingMovies</content>
```

**Line ~180 (Popular Movies):**
```xml
<content target="video">plugin://plugin.video.seren/?action=popularMovies</content>
```

See `ADDON_PATHS_REFERENCE.txt` for your addon's specific paths.

### Step 4: Activate the Widget Home Screen

```bash
cd xml/
mv Home.xml Home_Original.xml
mv Home_WithWidgets.xml Home.xml
```

### Step 5: Reload Kodi

In Kodi: Press `Ctrl + Alt + R` (or restart Kodi)

## Done! 🎉

Your home screen now shows:
- ✅ Trending movies from your addon
- ✅ Beautiful TMDB artwork
- ✅ Click to play directly
- ✅ HBO Max styling

## Customize Further

### Add More Content Rows

Want TV shows, genres, your Trakt list?

Edit `xml/Home.xml` and add more panels using the template in `WIDGET_SETUP_GUIDE.md`

### Change Categories

Don't want trending? Change to popular, anticipated, genres, etc.

Just update the `<content>` paths with different actions from `ADDON_PATHS_REFERENCE.txt`

### Add Section Labels

Add a label above each widget row:

```xml
<control type="label">
    <left>0</left>
    <top>515</top>
    <width>1800</width>
    <height>30</height>
    <font>font_body</font>
    <textcolor>hbo_purple</textcolor>
    <label>🔥 TRENDING NOW</label>
</control>
```

## Testing

### Verify Content Loads

1. Navigate to home screen
2. You should see movie posters
3. If blank: Check addon paths are correct
4. If error: Check kodi.log for details

### Test Playback

1. Focus on a movie
2. Press Enter/Select
3. Should start playing via your addon + Real-Debrid
4. Your VideoOSD.xml controls appear

### Test Info/Trailers

1. Focus on a movie
2. Info panel should appear on right
3. Press Info button to see full details
4. Press Trailer button to watch trailer

## Troubleshooting

### No Content Showing

**Problem:** Empty widgets

**Fix:**
1. Check addon paths in ADDON_PATHS_REFERENCE.txt
2. Test path in Kodi file browser first
3. Ensure addon is authorized (Trakt, Debrid)

### Content Shows But Won't Play

**Problem:** Click does nothing or error

**Fix:**
1. Test playing through addon directly
2. Check Real-Debrid is authorized
3. Check addon scraper settings
4. Look at kodi.log for errors

### Slow Loading

**Problem:** Content takes long to appear

**Fix:**
1. First load builds cache - normal
2. Enable caching in addon settings
3. Reduce number of items in widget
4. Check internet connection

## What Each File Does

- **Home.xml** - The actual home screen Kodi uses
- **Home_Original.xml** - Backup of simple version
- **Home_WithWidgets.xml** - Template with addon integration
- **WIDGET_SETUP_GUIDE.md** - Detailed setup instructions
- **ADDON_PATHS_REFERENCE.txt** - Common addon URLs
- **STREAMING_APP_GUIDE.md** - How everything works

## Next Steps

Once basic widgets work:

1. **Add TV Shows Section**
   - Copy movie widget
   - Change content path to TV shows
   - Update labels

2. **Add Genre Sections**
   - Create widgets for Action, Comedy, Horror, etc.
   - Use genre-specific paths

3. **Add My List**
   - Connect to your Trakt watchlist
   - Shows your personal content

4. **Add Search**
   - Already configured in top menu
   - Links to addon's search

5. **Install Extended Info**
   - Better movie/TV info dialogs
   - Cast info, reviews, similar titles

## Full Streaming App Experience

With everything configured, you'll have:

- ✅ Beautiful HBO Max styled interface
- ✅ Content from your addon (with Real-Debrid)
- ✅ TMDB artwork and metadata
- ✅ Trakt integration
- ✅ Trailers
- ✅ Info dialogs
- ✅ Search
- ✅ Categories and genres
- ✅ Click and play
- ✅ Professional OSD controls

All without ever seeing the addon's interface!

## Example: Complete Seren Setup

For Seren addon specifically:

1. Replace all instances:
   - `plugin.video.YOURADDON` → `plugin.video.seren`

2. Main widgets work automatically:
   - Trending Movies ✅
   - Popular Movies ✅

3. Add TV shows (optional):
   - Copy movie widget
   - Change to: `plugin://plugin.video.seren/?action=trendingShows`

4. Add My Movies (optional):
   - Change content to: `plugin://plugin.video.seren/?action=myMovies`

5. Done! Reload skin.

## Support

If you get stuck:

1. Check `WIDGET_SETUP_GUIDE.md` for detailed help
2. Look at `ADDON_PATHS_REFERENCE.txt` for correct paths
3. Enable debug logging and check kodi.log
4. Test addon works normally first
5. Verify paths work in file browser before adding to skin

---

**You now have a complete streaming app interface!** 🎬✨
