# Comparison: HBO Max Skin vs Arctic Zephyr

## Key Differences Found

### 1. **Folder Structure**

**Arctic Zephyr:**
```
skin.arctic.zephyr.mod/
├── 1080i/              ← XML files here (not "xml")
├── addon.xml
├── colors/             ← Separate folder for themes
├── fonts/
├── media/
├── language/           ← Translation files
├── resources/
└── shortcuts/
```

**Your HBO Max Skin:**
```
skin.hbomax/
├── xml/                ← Should be "1080i"
├── addon.xml
├── fonts/
├── media/
└── themes/
```

**🔴 ISSUE: You need to rename `xml/` to `1080i/`**

### 2. **Required Dependencies**

**Arctic Zephyr requires these addons:**
```xml
<import addon="script.skinshortcuts" version="0.4.0"/>
<import addon="script.globalsearch" version="5.0.0"/>
<import addon="script.image.resource.select" version="0.0.5"/>
<import addon="resource.images.weathericons.white" version="0.0.6"/>
<import addon="script.embuary.info" version="0.0.1"/>
<import addon="script.embuary.helper" version="1.2.14"/>
<import addon="plugin.video.themoviedb.helper" version="0.0.1"/>
```

**Your HBO Max Skin:**
```xml
<import addon="xbmc.gui" version="5.15.0"/>
```

**💡 KEY ADDONS FOR WIDGETS:**
- `plugin.video.themoviedb.helper` - **ESSENTIAL** for widgets/content
- `script.skinshortcuts` - For customizable menus
- `script.embuary.helper` - For artwork and helper functions

### 3. **Widget Implementation**

Arctic Zephyr uses:
- TMDbHelper for content widgets
- SkinShortcuts for menu building
- Custom Hub files (Custom_Hub_1111.xml through Custom_Hub_1119.xml)
- Widget containers with IDs 301, 8000-8119

### 4. **File Count**

**Arctic Zephyr**: 183 XML files
**Your Skin**: 22 XML files

**Missing Essential Files:**
```
MyMusicNav.xml
MyPictures.xml
MyWeather.xml
SmartPlaylistEditor.xml
SettingsCategory.xml
SettingsSystemInfo.xml
PlayerControls.xml
EventLog.xml
```

### 5. **Includes Structure**

Arctic Zephyr breaks includes into multiple files:
```
Includes.xml
Includes_Animations.xml
Includes_Custom_Items.xml
Includes_Defs.xml
Includes_DialogAddonInfo.xml
Includes_Furniture.xml
Includes_Home.xml
Includes_Images.xml
Includes_Labels.xml
Includes_Lists.xml
Includes_OSD.xml
Includes_PVR.xml
Includes_SubItems_Home.xml
```

Your skin has only:
```
Includes.xml
```

### 6. **View Types**

Arctic Zephyr has 40+ view files:
```
View_50_List.xml
View_500_Thumbnails.xml
View_501_Modern_Fanart.xml
View_504_Netflix.xml  ← Netflix-style view!
View_519_Shift_Modern.xml
... many more
```

Your skin has:
```
Views.xml (contains 3 views inline)
```

## What You Need To Add

### Critical Changes

#### 1. Rename xml folder
```bash
cd /Users/michaelhernandez/skin.hbomax
mv xml 1080i
```

#### 2. Update addon.xml

Add to your `<requires>` section:
```xml
<import addon="plugin.video.themoviedb.helper" version="0.0.1"/>
<import addon="script.skinshortcuts" version="0.4.0"/>
<import addon="script.embuary.helper" version="1.2.14"/>
```

Change folder reference:
```xml
<res width="1920" height="1080" aspect="16:9" default="true" folder="1080i" />
```

### Recommended Additions

#### 1. **MyMusicNav.xml** - For music library
#### 2. **MyPictures.xml** - For photos
#### 3. **MyWeather.xml** - For weather
#### 4. **SettingsCategory.xml** - Better settings navigation
#### 5. **PlayerControls.xml** - Unified player controls
#### 6. **EventLog.xml** - System notifications

### Widget Implementation Strategy

#### Option A: Use TMDbHelper (Like Arctic Zephyr)

**Pros:**
- Professional approach
- Built-in caching
- TMDB integration
- Used by major skins

**Cons:**
- Requires TMDbHelper addon
- More complex setup

**Implementation:**
```xml
<content target="video">
    plugin://plugin.video.themoviedb.helper/?info=trending&type=movie
</content>
```

#### Option B: Direct Addon Integration (Your Current Approach)

**Pros:**
- Works directly with your addon
- Simpler
- No middleman

**Cons:**
- Depends on specific addon
- Less flexible

**Implementation:**
```xml
<content target="video">
    plugin://plugin.video.seren/?action=trendingMovies
</content>
```

#### Option C: Hybrid Approach (Best)

Use TMDbHelper for metadata/artwork, your addon for playback:
```xml
<!-- TMDbHelper provides content -->
<content target="video">
    plugin://plugin.video.themoviedb.helper/?info=trending&type=movie
</content>

<!-- But onclick uses your addon to play -->
<onclick>RunPlugin(plugin://plugin.video.seren/?action=playItem&tmdb_id=$INFO[ListItem.Property(tmdb_id)])</onclick>
```

## File Structure Comparison

### Your Current Structure (Good Foundation)
```
✅ Home.xml
✅ MyVideoNav.xml
✅ Views.xml
✅ VideoOSD.xml
✅ DialogVideoInfo.xml
✅ Settings.xml
✅ DialogContextMenu.xml
✅ DialogSelect.xml
✅ DialogBusy.xml
✅ DialogConfirm.xml
✅ DialogNotification.xml
✅ FileManager.xml
✅ Font.xml
✅ colors.xml
✅ Includes.xml
```

### Should Add (From Arctic Zephyr)
```
⭕ MyMusicNav.xml
⭕ MyPictures.xml
⭕ MyWeather.xml
⭕ SettingsCategory.xml
⭕ SettingsSystemInfo.xml
⭕ PlayerControls.xml
⭕ EventLog.xml
⭕ SmartPlaylistEditor.xml
⭕ Includes_Animations.xml
⭕ Includes_Home.xml (widget specific)
⭕ Includes_Lists.xml
```

### Optional But Good
```
⚪ SkinSettings.xml (custom skin settings)
⚪ Custom_*.xml files (helper windows)
⚪ Startup.xml (first run setup)
```

## Action Plan

### Phase 1: Critical Fixes (Required)
1. ✅ Rename `xml/` to `1080i/`
2. ✅ Update `addon.xml` folder reference
3. ✅ Add TMDbHelper dependency
4. ✅ Test skin loads

### Phase 2: Widget Enhancement
1. ✅ Install `plugin.video.themoviedb.helper`
2. ✅ Update Home.xml with TMDbHelper widgets
3. ✅ Test content displays

### Phase 3: Missing Windows
1. ⭕ Add MyMusicNav.xml
2. ⭕ Add MyWeather.xml
3. ⭕ Add SettingsCategory.xml
4. ⭕ Add EventLog.xml

### Phase 4: Polish
1. ⚪ Split Includes into multiple files
2. ⚪ Add more view types
3. ⚪ Add skin settings window
4. ⚪ Add startup helper

## Key Learnings

### 1. Folder Must Be "1080i" Not "xml"
Kodi expects resolution-based folder names. Standard is:
- `1080i/` for 1920x1080
- `720p/` for 1280x720
- `16x9/` for 16:9 aspect

### 2. TMDbHelper Is The Standard
Most professional skins use TMDbHelper for:
- Content widgets
- Metadata
- Artwork
- Trending/Popular lists

### 3. Dependencies Matter
Arctic Zephyr requires 7 addon dependencies. You can start with just TMDbHelper.

### 4. File Organization
Large skins split Includes.xml into multiple files for maintainability:
- Includes_Home.xml (home widgets)
- Includes_Lists.xml (list layouts)
- Includes_Animations.xml (animation definitions)

### 5. Window IDs
Make sure your window IDs match Kodi standards:
- `<window id="0">` = Home
- `<window id="videos">` = MyVideoNav
- `<window id="settings">` = Settings
- etc.

## Next Steps

I'll create:
1. ✅ Instructions to rename folder
2. ✅ Updated addon.xml
3. ✅ Home.xml with TMDbHelper integration
4. ✅ Missing essential XML files
5. ✅ Setup guide for TMDbHelper

This will bring your skin to Arctic Zephyr's level of functionality!
